function cal()
{
    return(
    <div>
        this is no add {10+30}
    </div>)
}
export default cal;