import logo from './logo.svg';
import { useState } from 'react';
import './App.css';

import Click from './longday';

function App() {
 
  return (
    <div>

      <Click/>
      {/* <Click data={["kick me out"," abhi"]}
              name="abhishek"/>
       */}
      </div>
   
  );
}

export default App;
