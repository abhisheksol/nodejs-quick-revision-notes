import react, { Component } from "react"
export default class abhi extends Component{

    render(){
       
        return(
        <div>
            <h1>hello abhi this is the class compents</h1>
            
        </div>)
    }
}